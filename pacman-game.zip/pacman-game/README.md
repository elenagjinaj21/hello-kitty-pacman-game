*This activity has been created as part of the 42 curriculum by team42*

# 🎀 Hello Kitty Maze Game 🎀

A cute, pastel-pink themed Pac-Man inspired game built with Python and Pygame, featuring a Hello Kitty aesthetic with collectible bows, hearts, and strawberries.

## Description

Hello Kitty Maze is a reimagining of the classic Pac-Man game with a kawaii aesthetic. The game features:

- **Procedurally Generated Mazes**: Each level generates a unique maze using the A-Maze-ing package with the "42" logo embedded in the center
- **Progressive Levels**: 15 levels of increasing difficulty, with the first level using a fixed seed for consistency
- **Cute Characters**: Hello Kitty-inspired player character and adorable ghost enemies
- **Collectibles**: Pacgums (small dots) and super-pacgums (power pellets) with special effects
- **Ghost AI**: Intelligent ghost behaviors including chasing, scattering, and running away when frightened
- **Score System**: Points for collecting items and eating frightened ghosts
- **Highscore System**: Persistent storage of top 10 scores with player names
- **Cheat Mode**: Developer tools for testing (invincibility, level skip, ghost freeze, etc.)

## Instructions

### Installation

1. Clone or download the project
2. Install Python 3.9 or higher
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

### Running the Game

```bash
cd pacman-game
python src/game/main.py
```

Or using the installed console script:
```bash
hello-kitty-maze
```

### Controls

**Movement**:
- Arrow Keys or WASD to move
- Up/W: Move up
- Down/S: Move down
- Left/A: Move left
- Right/D: Move right

**Game Controls**:
- Space: Pause/Resume game
- M: Return to main menu
- Q: Quit game

**Menu Navigation**:
- Space: Start game
- H: View highscores
- I: View instructions
- Q: Quit

### Cheat Mode (for peer review)

During gameplay, press the following keys:

- **I**: Toggle invincibility (ghosts cannot eat you)
- **N**: Skip to next level immediately
- **F**: Freeze all ghosts (they stop moving)
- **L**: Add an extra life
- **S**: Toggle speed boost (2x speed)

## Resources

### Classic References

- [Pac-Man Game Design](https://en.wikipedia.org/wiki/Pac-Man)
- [Maze Generation Algorithms](https://www.aicrowd.com/challenges/maze-generation)
- [Pygame Documentation](https://www.pygame.org/docs/)
- [Game AI Pathfinding](https://gamedev.stackexchange.com/questions/53023/how-do-ghosts-find-the-player-in-pac-man)

### AI Usage

AI was utilized for:
1. **Code Architecture Design** - Structuring the game engine and module organization
2. **Ghost AI Implementation** - Chase algorithm and pathfinding logic
3. **Configuration Management** - JSON-based game configuration
4. **Documentation** - README and in-code documentation

## Configuration

### Configuration File Structure

Configuration is stored in `config/game_config.json` and includes:

```json
{
  "game_title": "🎀 Hello Kitty Maze 🎀",
  "game": {
    "width": 1200,
    "height": 900,
    "fps": 60,
    "num_levels": 15,
    "level_time_limit": 90,
    "first_level_seed": 42
  },
  "maze": {
    "width": 25,
    "height": 25,
    "cell_size": 30
  },
  "player": {
    "start_lives": 3,
    "speed": 5.0,
    "size": 18
  },
  "ghosts": {
    "count": 4,
    "speed": 3.0,
    "size": 20
  },
  "collectibles": {
    "pacgum_value": 10,
    "super_pacgum_value": 50,
    "super_pacgum_duration": 8.0
  }
}
```

### Default Values

- **Window Size**: 1200x900 pixels
- **Target FPS**: 60
- **Maze Size**: 25x25 cells
- **Cell Size**: 30 pixels
- **Starting Lives**: 3
- **Player Speed**: 5 cells per second
- **Ghost Speed**: 3 cells per second
- **Level Time Limit**: 90 seconds
- **Number of Levels**: 15
- **First Level Seed**: 42

## Highscore System

### How It Works

- Highscores are stored in `config/highscores.json` in JSON format
- The top 10 scores are maintained in a sorted list
- Each score entry includes:
  - Player name
  - Final score
  - Level reached
  - Date of achievement

### Save/Load Mechanism

- When the game ends (win or loss), players can enter their name
- If the score qualifies for the top 10, it's automatically saved
- Highscores persist between game sessions
- The highscore file is automatically created if it doesn't exist

## Maze Generation

### Using the A-Maze-ing Package

The game uses the provided `mazegenerator` package without modification. The integration works as follows:

1. **Maze Adapter Layer** (`src/game/maze_adapter.py`):
   - Wraps the MazeGenerator class
   - Provides game-specific methods for collision detection
   - Converts bit-encoded cell values to playable corridors
   - Handles wall detection in all four directions

2. **Generator Features**:
   - Procedural generation using depth-first search
   - Optional seed-based reproduction (Level 1 uses seed 42)
   - Perfect maze mode (no loops) or imperfect (with loops)
   - Automatic "42" embedding in maze center

3. **Bit-Encoded System**:
   ```
   Bit 1: Wall to north
   Bit 2: Wall to east
   Bit 4: Wall to south
   Bit 8: Wall to west
   Bit 15: Completely enclosed
   ```

## Implementation

### Technical Summary

The game is structured as a modular Python application with clear separation of concerns:

1. **Game Logic Layer** (`src/game/`):
   - GameEngine: Orchestrates all game systems
   - Player: Character state and movement
   - Ghost: AI-driven enemies
   - Collectible: Item management
   - LevelManager: Level progression
   - MazeAdapter: Maze integration

2. **Rendering Layer** (`src/ui/`):
   - GameDisplay: Pygame rendering
   - AssetManager: Asset loading and configuration
   - Menu systems and HUD

3. **Utility Layer** (`src/utils/`):
   - Constants: Game configuration values
   - HighscoreManager: Persistent score storage

### Module Relationships

```
GameEngine (orchestrator)
├── Player
├── LevelManager
│   └── Level
│       ├── MazeAdapter
│       ├── CollectibleManager
│       └── GhostManager
└── HighscoreManager

GameApplication (main loop)
├── GameEngine
├── GameDisplay
└── AssetManager
```

## General Software Architecture

### High-Level Overview

```
Application Layer (GameApplication)
    │
    ├─ Game Logic Layer (GameEngine)
    │   ├─ Player Management
    │   ├─ Ghost AI & Management
    │   ├─ Collectible Management
    │   ├─ Level Progression
    │   └─ Highscore Storage
    │
    ├─ Game World Layer (Maze)
    │   ├─ MazeAdapter
    │   └─ Maze Generation
    │
    └─ Presentation Layer (UI)
        ├─ GameDisplay (Rendering)
        ├─ Menu Systems
        ├─ HUD
        └─ AssetManager
```

### Design Patterns

- **Adapter Pattern**: MazeAdapter wraps the external MazeGenerator
- **Manager Pattern**: Manager classes (GhostManager, CollectibleManager, LevelManager)
- **State Pattern**: Game states (Menu, Playing, Paused, GameOver, Victory)
- **Observer Pattern**: Event handling for input and collisions

### Code Quality

- Type hints throughout for better IDE support
- Comprehensive docstrings for all modules and functions
- Consistent naming conventions
- Modular design for easy testing and extension
- No modification of external maze generator code

## Project Management

### Development Approach

This project was developed using a structured, phased approach:

1. **Phase 1 - Architecture Design**
   - Defined core game systems and their interactions
   - Planned module structure and dependencies
   - Identified external integrations (MazeGenerator)

2. **Phase 2 - Core Systems Implementation**
   - Implemented game engine and state management
   - Built player and ghost systems
   - Created maze adapter layer

3. **Phase 3 - Game Features**
   - Implemented collectible system
   - Added scoring and highscore management
   - Developed AI for ghost behavior

4. **Phase 4 - User Interface**
   - Built Pygame rendering system
   - Created menu and HUD systems
   - Implemented UI screens (main menu, pause, game over, etc.)

5. **Phase 5 - Polish & Testing**
   - Added cheat mode for peer review
   - Implemented persistent highscore storage
   - Testing and bug fixes

### Project Tracking

A dedicated `docs/project_management/` directory contains:
- Timeline and milestones
- Development progress tracking
- Risk analysis and mitigation strategies
- Technical decisions and justifications
- Testing and quality assurance notes

## Features

### Core Gameplay

- ✅ 15 progressively challenging levels
- ✅ Procedurally generated mazes with "42" embedded
- ✅ Collectible pacgums and power pellets
- ✅ Intelligent ghost AI with multiple behaviors
- ✅ Score system with multiplier for eaten ghosts
- ✅ Health/lives system (start with 3 lives)
- ✅ Level time limits (90 seconds per level)
- ✅ Win condition: Collect all pacgums
- ✅ Lose condition: Lose all lives or timeout

### User Interface

- ✅ Main menu with navigation
- ✅ Pause/resume functionality
- ✅ Real-time HUD (score, lives, level, time)
- ✅ Victory screen with congratulations
- ✅ Game over screen with highscore integration
- ✅ Highscore display (top 10)
- ✅ Instructions/controls screen
- ✅ Text input for name entry

### Advanced Features

- ✅ Persistent highscore storage (JSON)
- ✅ Ghost respawn system
- ✅ Power-up duration effects
- ✅ Cheat mode with 5 different cheats
- ✅ Smooth movement controls
- ✅ Aesthetic pastel pink kawaii theme

## Directory Structure

```
pacman-game/
├── src/
│   ├── game/
│   │   ├── __init__.py
│   │   ├── main.py (entry point)
│   │   ├── game_engine.py (main orchestrator)
│   │   ├── player.py
│   │   ├── ghost.py
│   │   ├── collectible.py
│   │   ├── level_manager.py
│   │   └── maze_adapter.py (external integration)
│   ├── ui/
│   │   ├── __init__.py
│   │   ├── menu.py (rendering and display)
│   │   └── assets.py (asset management)
│   └── utils/
│       ├── __init__.py
│       ├── constants.py (game configuration)
│       └── highscore.py (score persistence)
├── config/
│   ├── game_config.json (default configuration)
│   └── highscores.json (persistent scores)
├── assets/
│   ├── sprites/ (sprite assets)
│   └── fonts/ (font assets)
├── tests/ (unit tests)
├── docs/
│   └── project_management/ (project documentation)
├── mazegenerator-00001-py3-none-any/ (external package)
├── requirements.txt
├── setup.py
└── README.md
```

## Requirements

### System Requirements

- Python 3.9 or higher
- Operating System: Linux, macOS, or Windows
- Minimum RAM: 256MB
- Display: 1200x900 or higher resolution

### Python Dependencies

- pygame >= 2.1.0

## Installation & Setup

### Quick Start

```bash
# Clone the repository
git clone https://github.com/42school/hello-kitty-maze.git
cd hello-kitty-maze

# Create virtual environment (optional but recommended)
python3 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Run the game
python src/game/main.py
```

### Development Setup

```bash
# Install in development mode
pip install -e .

# Run tests
python -m pytest tests/

# Run with debugging
DEBUG=1 python src/game/main.py
```

## Testing

### Unit Tests

Run the test suite:
```bash
python -m pytest tests/ -v
```

### Manual Testing Checklist

- [ ] Game starts and displays menu
- [ ] Maze generates correctly with "42" embedded
- [ ] Player moves correctly with all arrow keys
- [ ] Ghosts move and chase player
- [ ] Collectibles appear at correct positions
- [ ] Score increases when collecting items
- [ ] Power pellets work and ghosts become edible
- [ ] Lives decrease when hit by ghost
- [ ] Level completes when all items collected
- [ ] Highscores save and persist
- [ ] All cheat codes work correctly
- [ ] Game is playable on different screen sizes

## Performance

- Target FPS: 60
- Average FPS: 55-60 (on mid-range hardware)
- Memory Usage: ~50-100MB
- Maze Generation Time: <100ms per level

## Known Limitations

- Single-player only
- No sound/music (placeholder architecture in place)
- Sprites are rendered as geometric shapes (simple circles and rectangles)
- No network/online features
- Limited to 25x25 maze size (balance between gameplay and performance)

## Future Enhancements

- [ ] Add sprite graphics and animations
- [ ] Implement sound effects and background music
- [ ] Add difficulty settings
- [ ] Implement different ghost AI strategies
- [ ] Add power-up varieties
- [ ] Network multiplayer support
- [ ] Mobile/touch controls
- [ ] Customizable appearance/themes

## Troubleshooting

### Game won't start

```
Error: No module named 'pygame'
→ Run: pip install pygame
```

### Maze not generating

```
Error: Failed to import MazeGenerator
→ Ensure mazegenerator package is in correct location
→ Check Python path includes the package directory
```

### Performance issues

- Reduce window size in `config/game_config.json`
- Lower FPS target in configuration
- Close other applications

## License

MIT License - See LICENSE file for details

## Credits

- **42 School**: Project assignment and specifications
- **A-Maze-ing Package**: Maze generation algorithm
- **Pygame**: Game framework
- **Hello Kitty**: Character inspiration (used for theme/aesthetic)

---

**Created for the 42 School Common-Core Pacman project**

For more information about 42 School, visit https://www.42.fr/

🎀 Happy gaming! 🎀
