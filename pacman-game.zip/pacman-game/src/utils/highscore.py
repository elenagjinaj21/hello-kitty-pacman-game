"""Highscore management system."""

import json
from datetime import datetime
from pathlib import Path
from typing import List, Dict

from utils.constants import HIGHSCORE_FILE, MAX_HIGHSCORES


class HighscoreManager:
    """Manages game highscores and persistent storage."""

    def __init__(self):
        """Initialize the highscore manager."""
        self.highscores: List[Dict[str, any]] = []
        self.load_highscores()

    def load_highscores(self) -> None:
        """Load highscores from file."""
        if HIGHSCORE_FILE.exists():
            try:
                with open(HIGHSCORE_FILE, 'r') as f:
                    self.highscores = json.load(f)
            except (json.JSONDecodeError, IOError):
                self.highscores = []
        else:
            self.highscores = []

    def save_highscores(self) -> None:
        """Save highscores to file."""
        HIGHSCORE_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(HIGHSCORE_FILE, 'w') as f:
            json.dump(self.highscores, f, indent=2)

    def add_score(self, name: str, score: int, level: int) -> int:
        """
        Add a new score to the highscore list.

        Args:
            name: Player name
            score: Final score
            level: Level reached

        Returns:
            Position in highscore list (1-indexed), or -1 if not in top 10
        """
        entry = {
            "name": name,
            "score": score,
            "level": level,
            "date": datetime.now().isoformat()
        }

        self.highscores.append(entry)
        self.highscores.sort(key=lambda x: x["score"], reverse=True)
        self.highscores = self.highscores[:MAX_HIGHSCORES]

        position = next(
            (i for i, h in enumerate(self.highscores) if h == entry),
            -1
        )
        self.save_highscores()

        return position + 1 if position >= 0 else -1

    def get_top_scores(self, limit: int = 10) -> List[Dict[str, any]]:
        """Get top scores."""
        return self.highscores[:limit]

    def is_highscore(self, score: int) -> bool:
        """Check if score qualifies for highscores."""
        if len(self.highscores) < MAX_HIGHSCORES:
            return True
        return score > self.highscores[-1]["score"]

    def clear_highscores(self) -> None:
        """Clear all highscores (for testing)."""
        self.highscores = []
        self.save_highscores()
