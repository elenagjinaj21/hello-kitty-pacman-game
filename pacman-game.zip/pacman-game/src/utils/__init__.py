"""Utils module initialization."""

from utils.constants import *
from utils.highscore import HighscoreManager

__all__ = [
    "HighscoreManager",
]
