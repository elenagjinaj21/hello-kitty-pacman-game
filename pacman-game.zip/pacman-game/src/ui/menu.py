"""Main game display and rendering."""

from typing import Optional, Tuple, List
import pygame
from pygame.locals import *

from utils.constants import (
    WINDOW_WIDTH, WINDOW_HEIGHT, FPS,
    COLOR_BACKGROUND, COLOR_WALL, COLOR_WALL_DARK, COLOR_CORRIDOR,
    COLOR_TEXT, COLOR_TEXT_DARK, COLOR_HIGHLIGHT,
    CELL_SIZE, PACGUM_SIZE, SUPER_PACGUM_SIZE,
    PLAYER_SIZE, GHOST_SIZE,
    UI_PADDING, UI_FONT_SIZE_LARGE, UI_FONT_SIZE_MEDIUM, UI_FONT_SIZE_SMALL
)
from ui.assets import AssetManager


class GameDisplay:
    """Handles all game rendering."""

    def __init__(self, caption: str = "Hello Kitty Maze Game"):
        """
        Initialize the game display.

        Args:
            caption: Window title
        """
        import os

        pygame.init()

        # Check for display availability
        if not os.environ.get('DISPLAY'):
            print("⚠️  Warning: No X11 display found!")
            print("If running remotely, use: ssh -X user@host")
            print("Or create virtual display: Xvfb :99 -screen 0 1200x900x24 &")

        try:
            self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
            pygame.display.set_caption(caption)
        except pygame.error as e:
            print(f"❌ Display Error: {e}")
            print("Trying to continue with fallback display...")
            self.screen = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))

        self.clock = pygame.time.Clock()
        self.asset_manager = AssetManager()

        # Fonts
        self.font_large = pygame.font.Font(None, UI_FONT_SIZE_LARGE)
        self.font_medium = pygame.font.Font(None, UI_FONT_SIZE_MEDIUM)
        self.font_small = pygame.font.Font(None, UI_FONT_SIZE_SMALL)

    def draw_maze(self, maze_adapter) -> None:
        """Draw the maze."""
        maze = maze_adapter.get_maze_grid()
        for y, row in enumerate(maze):
            for x, cell in enumerate(row):
                pixel_x = x * CELL_SIZE
                pixel_y = y * CELL_SIZE

                # Draw corridor
                pygame.draw.rect(
                    self.screen,
                    COLOR_CORRIDOR,
                    (pixel_x, pixel_y, CELL_SIZE, CELL_SIZE)
                )

                # Draw walls as borders
                if maze_adapter.is_wall_north(x, y):
                    pygame.draw.line(
                        self.screen, COLOR_WALL_DARK,
                        (pixel_x, pixel_y),
                        (pixel_x + CELL_SIZE, pixel_y), 2
                    )
                if maze_adapter.is_wall_south(x, y):
                    pygame.draw.line(
                        self.screen, COLOR_WALL_DARK,
                        (pixel_x, pixel_y + CELL_SIZE),
                        (pixel_x + CELL_SIZE, pixel_y + CELL_SIZE), 2
                    )
                if maze_adapter.is_wall_west(x, y):
                    pygame.draw.line(
                        self.screen, COLOR_WALL_DARK,
                        (pixel_x, pixel_y),
                        (pixel_x, pixel_y + CELL_SIZE), 2
                    )
                if maze_adapter.is_wall_east(x, y):
                    pygame.draw.line(
                        self.screen, COLOR_WALL_DARK,
                        (pixel_x + CELL_SIZE, pixel_y),
                        (pixel_x + CELL_SIZE, pixel_y + CELL_SIZE), 2
                    )

                # Highlight the 42 area
                if maze_adapter.is_42_cell(x, y):
                    pygame.draw.rect(
                        self.screen,
                        COLOR_HIGHLIGHT,
                        (pixel_x + 2, pixel_y + 2, CELL_SIZE - 4, CELL_SIZE - 4)
                    )

    def draw_collectibles(self, collectible_manager) -> None:
        """Draw all collectibles."""
        for collectible in collectible_manager.get_all_collectibles():
            if collectible.collected:
                continue

            pixel_x = collectible.x * CELL_SIZE + CELL_SIZE // 2
            pixel_y = collectible.y * CELL_SIZE + CELL_SIZE // 2

            if collectible.is_power_up:
                # Draw super-pacgum (larger, different color)
                pygame.draw.circle(
                    self.screen,
                    COLOR_TEXT,
                    (pixel_x, pixel_y),
                    SUPER_PACGUM_SIZE
                )
                pygame.draw.circle(
                    self.screen,
                    COLOR_TEXT_DARK,
                    (pixel_x, pixel_y),
                    SUPER_PACGUM_SIZE - 1
                )
            else:
                # Draw pacgum
                pygame.draw.circle(
                    self.screen,
                    COLOR_TEXT,
                    (pixel_x, pixel_y),
                    PACGUM_SIZE
                )

    def draw_player(self, player) -> None:
        """Draw the player."""
        pixel_x = player.x * CELL_SIZE + CELL_SIZE // 2
        pixel_y = player.y * CELL_SIZE + CELL_SIZE // 2
        radius = PLAYER_SIZE // 2

        # Draw player as a circle (Hello Kitty inspired - simple cute face)
        pygame.draw.circle(self.screen, COLOR_TEXT_DARK, (pixel_x, pixel_y), radius)

        # Draw eyes
        if player.current_direction.value[0] > 0:  # Facing right
            pygame.draw.circle(self.screen, (255, 255, 255), (pixel_x + 4, pixel_y - 3), 2)
        elif player.current_direction.value[0] < 0:  # Facing left
            pygame.draw.circle(self.screen, (255, 255, 255), (pixel_x - 4, pixel_y - 3), 2)
        else:
            pygame.draw.circle(self.screen, (255, 255, 255), (pixel_x - 3, pixel_y - 3), 2)
            pygame.draw.circle(self.screen, (255, 255, 255), (pixel_x + 3, pixel_y - 3), 2)

        # Invincibility indicator
        if player.is_invincible:
            pygame.draw.circle(
                self.screen,
                COLOR_HIGHLIGHT,
                (pixel_x, pixel_y),
                radius + 4,
                2
            )

    def draw_ghosts(self, ghost_manager) -> None:
        """Draw all ghosts."""
        for ghost in ghost_manager.get_ghosts():
            pixel_x = ghost.x * CELL_SIZE + CELL_SIZE // 2
            pixel_y = ghost.y * CELL_SIZE + CELL_SIZE // 2
            radius = GHOST_SIZE // 2

            if ghost.is_frightened():
                # Draw frightened ghost in different color
                pygame.draw.circle(self.screen, (100, 100, 255), (pixel_x, pixel_y), radius)
            else:
                # Draw normal ghost
                pygame.draw.circle(self.screen, ghost.color, (pixel_x, pixel_y), radius)

            # Draw eyes
            pygame.draw.circle(self.screen, (255, 255, 255), (pixel_x - 3, pixel_y - 3), 2)
            pygame.draw.circle(self.screen, (255, 255, 255), (pixel_x + 3, pixel_y - 3), 2)

    def draw_hud(self, game_engine) -> None:
        """Draw heads-up display."""
        hud_y = 10
        hud_text_color = COLOR_TEXT_DARK

        # Level
        level_text = self.font_small.render(
            f"Level: {game_engine.get_current_level_number()}",
            True,
            hud_text_color
        )
        self.screen.blit(level_text, (UI_PADDING, hud_y))

        # Score
        score_text = self.font_small.render(
            f"Score: {game_engine.get_player_score()}",
            True,
            hud_text_color
        )
        self.screen.blit(score_text, (UI_PADDING, hud_y + 35))

        # Lives
        lives_text = self.font_small.render(
            f"Lives: {game_engine.get_player_lives()}",
            True,
            hud_text_color
        )
        self.screen.blit(lives_text, (UI_PADDING + 300, hud_y))

        # Time
        time_text = self.font_small.render(
            f"Time: {game_engine.get_time_remaining()}s",
            True,
            hud_text_color
        )
        self.screen.blit(time_text, (UI_PADDING + 300, hud_y + 35))

    def draw_main_menu(self) -> None:
        """Draw main menu."""
        self.screen.fill(COLOR_BACKGROUND)

        # Title
        title = self.font_large.render(
            "🎀 Hello Kitty Maze 🎀",
            True,
            COLOR_TEXT_DARK
        )
        title_rect = title.get_rect(center=(WINDOW_WIDTH // 2, 150))
        self.screen.blit(title, title_rect)

        # Menu options
        menu_text = self.font_medium.render(
            "Press SPACE to Start",
            True,
            COLOR_TEXT
        )
        menu_rect = menu_text.get_rect(center=(WINDOW_WIDTH // 2, 350))
        self.screen.blit(menu_text, menu_rect)

        menu_text2 = self.font_medium.render(
            "Press H for Highscores",
            True,
            COLOR_TEXT
        )
        menu_rect2 = menu_text2.get_rect(center=(WINDOW_WIDTH // 2, 430))
        self.screen.blit(menu_text2, menu_rect2)

        menu_text3 = self.font_medium.render(
            "Press I for Instructions",
            True,
            COLOR_TEXT
        )
        menu_rect3 = menu_text3.get_rect(center=(WINDOW_WIDTH // 2, 510))
        self.screen.blit(menu_text3, menu_rect3)

        menu_text4 = self.font_small.render(
            "Press Q to Quit",
            True,
            COLOR_TEXT
        )
        menu_rect4 = menu_text4.get_rect(center=(WINDOW_WIDTH // 2, 650))
        self.screen.blit(menu_text4, menu_rect4)

    def draw_pause_menu(self) -> None:
        """Draw pause menu."""
        # Semi-transparent overlay
        overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
        overlay.set_alpha(200)
        overlay.fill((0, 0, 0))
        self.screen.blit(overlay, (0, 0))

        # Pause text
        pause_text = self.font_large.render(
            "PAUSED",
            True,
            COLOR_TEXT_DARK
        )
        pause_rect = pause_text.get_rect(center=(WINDOW_WIDTH // 2, 250))
        self.screen.blit(pause_text, pause_rect)

        # Instructions
        resume_text = self.font_medium.render(
            "Press SPACE to Resume",
            True,
            COLOR_TEXT
        )
        resume_rect = resume_text.get_rect(center=(WINDOW_WIDTH // 2, 400))
        self.screen.blit(resume_text, resume_rect)

        menu_text = self.font_medium.render(
            "Press M for Menu",
            True,
            COLOR_TEXT
        )
        menu_rect = menu_text.get_rect(center=(WINDOW_WIDTH // 2, 480))
        self.screen.blit(menu_text, menu_rect)

    def draw_game_over(self, score: int) -> None:
        """Draw game over screen."""
        self.screen.fill(COLOR_BACKGROUND)

        # Game Over text
        gameover_text = self.font_large.render(
            "GAME OVER",
            True,
            COLOR_TEXT_DARK
        )
        gameover_rect = gameover_text.get_rect(center=(WINDOW_WIDTH // 2, 200))
        self.screen.blit(gameover_text, gameover_rect)

        # Score
        score_text = self.font_medium.render(
            f"Final Score: {score}",
            True,
            COLOR_TEXT
        )
        score_rect = score_text.get_rect(center=(WINDOW_WIDTH // 2, 350))
        self.screen.blit(score_text, score_rect)

        # Instructions
        enter_text = self.font_small.render(
            "Enter your name and press ENTER to save score",
            True,
            COLOR_TEXT
        )
        enter_rect = enter_text.get_rect(center=(WINDOW_WIDTH // 2, 450))
        self.screen.blit(enter_text, enter_rect)

    def draw_victory(self, score: int) -> None:
        """Draw victory screen."""
        self.screen.fill(COLOR_BACKGROUND)

        # Victory text
        victory_text = self.font_large.render(
            "🎉 YOU WIN! 🎉",
            True,
            COLOR_TEXT_DARK
        )
        victory_rect = victory_text.get_rect(center=(WINDOW_WIDTH // 2, 200))
        self.screen.blit(victory_text, victory_rect)

        # Score
        score_text = self.font_medium.render(
            f"Final Score: {score}",
            True,
            COLOR_TEXT
        )
        score_rect = score_text.get_rect(center=(WINDOW_WIDTH // 2, 350))
        self.screen.blit(score_text, score_rect)

        # Instructions
        enter_text = self.font_small.render(
            "Enter your name and press ENTER to save score",
            True,
            COLOR_TEXT
        )
        enter_rect = enter_text.get_rect(center=(WINDOW_WIDTH // 2, 450))
        self.screen.blit(enter_text, enter_rect)

    def draw_text_input(self, text: str, prompt: str = "Name: ") -> None:
        """
        Draw text input field.

        Args:
            text: Current input text
            prompt: Input prompt
        """
        prompt_surf = self.font_medium.render(prompt + text + "|", True, COLOR_TEXT_DARK)
        prompt_rect = prompt_surf.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2))
        self.screen.blit(prompt_surf, prompt_rect)

    def draw_highscores(self, highscores: List) -> None:
        """Draw highscores screen."""
        self.screen.fill(COLOR_BACKGROUND)

        # Title
        title = self.font_large.render(
            "🏆 Highscores 🏆",
            True,
            COLOR_TEXT_DARK
        )
        title_rect = title.get_rect(center=(WINDOW_WIDTH // 2, 50))
        self.screen.blit(title, title_rect)

        # Highscores
        y_pos = 150
        for i, score_entry in enumerate(highscores[:10], 1):
            score_text = self.font_small.render(
                f"{i}. {score_entry['name']:<20} {score_entry['score']:>8} (Level {score_entry['level']})",
                True,
                COLOR_TEXT
            )
            self.screen.blit(score_text, (UI_PADDING, y_pos))
            y_pos += 40

        # Back instruction
        back_text = self.font_small.render(
            "Press SPACE to return to menu",
            True,
            COLOR_TEXT
        )
        back_rect = back_text.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT - 50))
        self.screen.blit(back_text, back_rect)

    def draw_instructions(self) -> None:
        """Draw instructions screen."""
        self.screen.fill(COLOR_BACKGROUND)

        # Title
        title = self.font_large.render(
            "📖 Instructions 📖",
            True,
            COLOR_TEXT_DARK
        )
        title_rect = title.get_rect(center=(WINDOW_WIDTH // 2, 30))
        self.screen.blit(title, title_rect)

        # Instructions
        instructions = [
            "Arrow Keys or WASD: Move",
            "Space: Pause/Resume",
            "M: Return to Menu",
            "",
            "Collect pacgums for points",
            "Collect power pellets to eat ghosts",
            "Avoid ghosts or you lose a life",
            "Collect all pacgums to win the level",
            "",
            "Cheat Mode (for testing):",
            "I: Toggle Invincibility",
            "N: Skip Level",
            "F: Freeze Ghosts",
            "L: Extra Life",
            "S: Speed Boost",
        ]

        y_pos = 120
        for instruction in instructions:
            if instruction:
                instr_text = self.font_small.render(instruction, True, COLOR_TEXT)
            else:
                instr_text = pygame.Surface((0, 0))
            self.screen.blit(instr_text, (UI_PADDING + 20, y_pos))
            y_pos += 35

        # Back instruction
        back_text = self.font_small.render(
            "Press SPACE to return to menu",
            True,
            COLOR_TEXT
        )
        back_rect = back_text.get_rect(center=(WINDOW_WIDTH // 2, WINDOW_HEIGHT - 50))
        self.screen.blit(back_text, back_rect)

    def clear_screen(self) -> None:
        """Clear the screen."""
        self.screen.fill(COLOR_BACKGROUND)

    def flip_display(self) -> None:
        """Update display."""
        try:
            pygame.display.flip()
        except pygame.error:
            # Display not available, continue anyway
            pass

    def tick(self, fps: int = FPS) -> float:
        """
        Tick the clock.

        Args:
            fps: Frames per second

        Returns:
            Delta time in seconds
        """
        try:
            return self.clock.tick(fps) / 1000.0
        except Exception:
            # Fallback if clock fails
            return 1.0 / fps

    def quit(self) -> None:
        """Quit pygame."""
        pygame.quit()
